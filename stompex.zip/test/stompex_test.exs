defmodule Stompex2Test do
  use ExUnit.Case
  doctest Stompex

end
